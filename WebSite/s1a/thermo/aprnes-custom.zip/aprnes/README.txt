AprNes — custom build for the AprVisual open-bus thermometer
============================================================

This is the AprVisual project's special build of AprNes (the reference NES emulator),
with the PPU open-bus decay modelled as a temperature-dependent (Arrhenius) discharge
and two extra headless CLI flags. It is NOT the stock AprNes; the thermometer ROM's
Celsius read-out is calibrated to THIS build.

Requires: Windows + .NET Framework 4.8.1 runtime (present on most Windows installs).

Files:
  AprNes.exe                                  the emulator
  AprNes.exe.config
  System.Numerics.Vectors.dll                 (dependency)
  System.Runtime.CompilerServices.Unsafe.dll  (dependency)

Run the thermometer ROM headless:
  AprNes.exe --rom thermo.nes --openbus-temp 25 --time 6 ^
             --dump-mem 0013 --timed-screenshots "shot.png:2.0"

Flags added by this build:
  --openbus-temp <C>    set the PPU open-bus decay temperature (default 25)
  --dump-mem <hexaddr>  print 8 bytes + the little-endian u24 at that CPU address at exit
                        (the ROM leaves the whole-degree temperature at $0013, and the
                         raw 24-bit decay count at $0010; range 0-100 C, per-degree exact)

Source: https://github.com/erspicu/AprVisual  ->  tools/aprnes/
Study : https://erspicu.github.io/AprVisual/s1a/aprnes-thermometer-tool.html
